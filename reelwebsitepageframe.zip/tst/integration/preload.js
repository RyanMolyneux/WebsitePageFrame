window.electronRequire = require;
